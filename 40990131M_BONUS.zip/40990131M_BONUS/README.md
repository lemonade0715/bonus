# README

請閱讀 bonus.pdf，並在此目錄下 make，各個可執行檔皆為範例程式，請依據 bonus.pdf 內的指示依序執行。

目錄 latex_files 內為建構 bonus.pdf 所用到的 LaTeX 相關檔案，如果沒有特別需求可以不用打開。

--
音樂三甲 江信彥
40990131M
